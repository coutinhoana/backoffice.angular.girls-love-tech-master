/**
 * Diz se deve criar com ele ativado ou desativado
 */
export class BasePayload {

  /**
   * Diz se deve criar com ele ativado ou desativado
   */
  isActive?: boolean;

}
