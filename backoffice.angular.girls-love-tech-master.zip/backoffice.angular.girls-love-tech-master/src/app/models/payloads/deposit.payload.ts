export interface DepositPayload {

  amount: number;
  reason: string;
  userId: number;

}
