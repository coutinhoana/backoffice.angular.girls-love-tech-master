export enum ProjectType{
  PESSOAL = 0,
  ACADEMICO = 1,
  CENTROS = 2,
}
