export enum EquipmentType {
  MACHINES = 0,
  FABGURUS = 1,
  SPACES = 2,
  TRAINING = 3,
}
