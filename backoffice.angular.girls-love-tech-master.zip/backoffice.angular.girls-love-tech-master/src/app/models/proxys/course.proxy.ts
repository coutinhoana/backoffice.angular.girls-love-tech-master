import { BaseProxy } from './base/base.proxy';

export interface CourseProxy extends BaseProxy {
  name: string;
}
